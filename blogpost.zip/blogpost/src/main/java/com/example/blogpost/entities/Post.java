package com.example.blogpost.entities;

import com.example.blogpost.enums.Category;
import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Post {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
   private String title;
   private String content;
   @CreatedDate
    private LocalDateTime createdAt;
   @LastModifiedDate
    private LocalDateTime modifiedAt;
   @Enumerated(EnumType.STRING)
    private Category category;
   @ManyToOne
    private Admin admin;
   @OneToMany()
    @JoinColumn
    private List<Comment> comment = new ArrayList<>();
   @OneToMany
    @JoinColumn
    private List<Likes> likes = new ArrayList<>();
}
