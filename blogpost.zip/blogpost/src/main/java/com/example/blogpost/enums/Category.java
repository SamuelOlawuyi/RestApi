package com.example.blogpost.enums;

public enum Category {
    TRAD, SUIT, CASUAL
}
